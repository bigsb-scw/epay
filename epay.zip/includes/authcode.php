<?php
define('authcode','bd80270814a19cbe68cbe5c049f3c541');

?>